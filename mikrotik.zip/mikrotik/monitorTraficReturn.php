<?php

session_start();

$user_id = isset($_SESSION['UserId']) ? $_SESSION['UserId'] : NULL;
$FullName = isset($_SESSION['FullName']) ? $_SESSION['FullName'] : NULL;
$UserName = isset($_SESSION['UserName']) ? $_SESSION['UserName'] : NULL;
$PhotoPath = isset($_SESSION['PhotoPath']) ? $_SESSION['PhotoPath'] : NULL;
$ty = isset($_SESSION['UserType']) ? $_SESSION['UserType'] : NULL;


if (!empty($_SESSION['UserId'])) {

//========================================
    include '../model/oop.php';
    require('../model/Mikrotik.php');
    $obj = new Controller();
    $mikrotikLoginData = $obj->details_by_cond('mikrotik_user', 'id = 1');
$ip='103.231.231.70';
$name='masud';
$pass='masud';
    $mikrotik = new Mikrotik($ip, $name, $pass);


    $mikrotikConnectOrDisconnect = $mikrotik->checkConnection();
    if ($mikrotik->checkConnection()) {

        $ARRAY = $mikrotik->monitorTrafic();

        echo json_encode(array(
            "rx_per_second" => ($ARRAY[0]['rx-bits-per-second'] / 1000),
            "tx_per_second" => ($ARRAY[0]['tx-bits-per-second'] / 1000),
        ));
    }
}
?>
